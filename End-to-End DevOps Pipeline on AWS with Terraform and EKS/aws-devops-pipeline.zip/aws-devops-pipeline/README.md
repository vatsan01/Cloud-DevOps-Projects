# End-to-End DevOps Pipeline on AWS with Terraform and EKS

This is a full-stack DevOps project.